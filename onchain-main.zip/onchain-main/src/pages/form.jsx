import { Formik } from "../components";

const Form = () => {
  return (
    <div>
      <Formik />
    </div>
  );
};

export default Form;
