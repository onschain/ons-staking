import { HomeCom } from "../components";

const Home = () => {
  return (
    <div>
      <HomeCom />
    </div>
  );
};

export default Home;
