import styled, { css } from "styled-components";

import { Form } from "react-bootstrap";

export const NftForms = styled(Form)``;

export const FormControl = styled(Form.Control)``;
