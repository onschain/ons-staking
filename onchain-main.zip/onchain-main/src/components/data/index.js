export const networkObj = [
    {
        name: "Ethereum",
        value: 'ethereum',
    },
    {
        name: "Avalanche",
        value: 'avax',
    },
    {
        name: "Binance Smart Chain",
        value: 'bsc',
    },
    {
        name: "Polygon",
        value: 'polygon',
    },
    
]