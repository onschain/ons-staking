export const stakingAbi = [
  {
    inputs: [
      { internalType: "address", name: "_onschainToken", type: "address" },
      { internalType: "address", name: "_initialOwner", type: "address" },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    inputs: [{ internalType: "address", name: "target", type: "address" }],
    name: "AddressEmptyCode",
    type: "error",
  },
  {
    inputs: [{ internalType: "address", name: "account", type: "address" }],
    name: "AddressInsufficientBalance",
    type: "error",
  },
  { inputs: [], name: "FailedInnerCall", type: "error" },
  {
    inputs: [{ internalType: "address", name: "owner", type: "address" }],
    name: "OwnableInvalidOwner",
    type: "error",
  },
  {
    inputs: [{ internalType: "address", name: "account", type: "address" }],
    name: "OwnableUnauthorizedAccount",
    type: "error",
  },
  {
    inputs: [{ internalType: "address", name: "token", type: "address" }],
    name: "SafeERC20FailedOperation",
    type: "error",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "address",
        name: "previousOwner",
        type: "address",
      },
      {
        indexed: true,
        internalType: "address",
        name: "newOwner",
        type: "address",
      },
    ],
    name: "OwnershipTransferred",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: "address", name: "user", type: "address" },
      {
        indexed: false,
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "RewardsClaimed",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: "address", name: "user", type: "address" },
      {
        indexed: false,
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "Staked",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: "address", name: "user", type: "address" },
      {
        indexed: false,
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "Unstaked",
    type: "event",
  },
  {
    inputs: [
      { internalType: "address", name: "user", type: "address" },
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
    ],
    name: "calculateRewards",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
    ],
    name: "claimRewards",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getStakeAmountAndTime",
    outputs: [
      { internalType: "uint256", name: "stakingTime", type: "uint256" },
      { internalType: "uint256", name: "stakingAmount", type: "uint256" },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getStakeEndTime",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getStakeStartTime",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
    ],
    name: "getStakingDetails",
    outputs: [
      { internalType: "uint256", name: "duration", type: "uint256" },
      { internalType: "uint256", name: "rewardsAPY", type: "uint256" },
      { internalType: "uint256", name: "minStakeAmount", type: "uint256" },
      { internalType: "uint256", name: "penaltyRate", type: "uint256" },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getUserClaimedRewards",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getUserStake",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "address", name: "user", type: "address" },
    ],
    name: "getUserStakingStatus",
    outputs: [{ internalType: "bool", name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "onschainToken",
    outputs: [{ internalType: "contract IERC20", name: "", type: "address" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "owner",
    outputs: [{ internalType: "address", name: "", type: "address" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "renounceOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
      { internalType: "uint256", name: "amount", type: "uint256" },
    ],
    name: "stake",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "newOwner", type: "address" }],
    name: "transferOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "enum OnschainStaking.StakingTier",
        name: "tier",
        type: "uint8",
      },
    ],
    name: "unstake",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
];
